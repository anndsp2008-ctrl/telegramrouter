<?php declare(strict_types=1);
namespace App;

use danog\MadelineProto\EventHandler;
use danog\MadelineProto\EventHandler\Message;
use danog\MadelineProto\ParseMode;
use danog\MadelineProto\SimpleEventHandler;
use danog\MadelineProto\StrTools;

final class TelegramRouter extends SimpleEventHandler
{
    public static function getPlugins(): array { return []; }
    public function getReportPeers(): array { return []; }

    public function onStart(): void
    {
        $pdo = Database::pdo();
        $pdo->prepare("INSERT INTO worker_status(worker_key,status,last_activity_at) VALUES('telegram-global','conectado',NOW()) ON DUPLICATE KEY UPDATE status='conectado',last_activity_at=NOW(),last_error=NULL")->execute();
    }

    #[EventHandler\Attributes\Handler]
    public function handleIncoming(Message $message): void
    {
        $text = (string) ($message->message ?? '');
        if ($text === '') return;
        $source = (string) ($message->chatId ?? $message->senderId ?? '');
        $peerInfo = [];
        try {
            $info = $this->getInfo($message->chatId);
            if (is_array($info)) $peerInfo = $info;
        } catch (\Throwable) {
            // O ID numérico continua disponível mesmo quando o cache do peer falha.
        }
        $identifiers = ChatMatcher::identifiers($source, $peerInfo);
        foreach (Repository::allRules() as $rule) {
            if (!(int) $rule['enabled'] || !$this->matches($identifiers, (string) $rule['source_chat'], $text, (string) $rule['trigger_text'])) continue;
            $this->process($message, $source, $rule);
            break;
        }
    }

    /** @param array<int,string> $identifiers */
    private function matches(array $identifiers, string $wanted, string $text, string $trigger): bool
    {
        return ChatMatcher::matches($identifiers, $wanted) && mb_stripos($text, $trigger) !== false;
    }

    private function process(Message $message, string $source, array $rule): void
    {
        $id = (int) $message->id;
        $pdo = Database::pdo();
        try {
            $s = $pdo->prepare("INSERT INTO router_events(source_chat,message_id,destination_chat,trigger_text,status) VALUES(?,?,?,?, 'processing')");
            $s->execute([$source, $id, $rule['destination_chat'], $rule['trigger_text']]);
        } catch (\PDOException $e) {
            if ((int) ($e->errorInfo[1] ?? 0) === 1062) return;
            throw $e;
        }

        try {
            $this->resolveDestination((string) $rule['destination_chat']);
            $cleaned = Transform::cleanWithEntities((string) $message->message, $rule, (array) ($message->entities ?? []));
            $text = Transform::translate($cleaned['text'], $rule);
            $realTranslation = !empty($rule['translation_enabled']) && (($rule['translation_provider'] ?? 'none') !== 'none') && $text !== $cleaned['text'];
            // A tradução devolve texto novo, portanto as entidades originais
            // não podem ser reaplicadas com os offsets antigos.
            $sendEntities = $realTranslation ? [] : $cleaned['entities'];
            if ($text === '') { $this->finish($source, $id, 'skipped', 'Texto vazio após limpeza'); return; }
            $mode = (string) $rule['media_mode'];
            if ($mode === 'text_only') {
                $params = ['peer'=>$rule['destination_chat'], 'message'=>$text, 'entities'=>(!$realTranslation ? $sendEntities : [])];
                $this->messages->sendMessage(...$params);
            } elseif ($mode === 'current_media' && !empty($message->media)) {
                $this->sendMediaWithSafeCaption((string) $rule['destination_chat'], $message->media, $text, $sendEntities);
            } else {
                $previous = $this->findAndClaimPreviousPhoto($message, $source, $id);
                if (!$previous) { $this->finish($source, $id, 'skipped', 'Nenhuma foto anterior encontrada nos últimos 15 minutos'); return; }
                $this->sendMediaWithSafeCaption((string) $rule['destination_chat'], $previous, $text, $sendEntities);
            }
            $this->finish($source, $id, 'forwarded', 'Mensagem encaminhada');
        } catch (\Throwable $e) {
            $this->finish($source, $id, 'failed', ErrorTranslator::message($e, 'o encaminhamento da mensagem'));
        }
    }

    private function resolveDestination(string $peer): void
    {
        try {
            $this->getInfo($peer);
            return;
        } catch (\Throwable $first) {
            // Um ID -100 sem access_hash só pode ser resolvido se a conta já
            // tiver esse canal nos diálogos. O carregamento popula o peer DB.
            try { $this->getFullDialogs(); } catch (\Throwable) {}
            try {
                $this->getInfo($peer);
                return;
            } catch (\Throwable) {
                throw new \RuntimeException('O destino '.$peer.' não está acessível pela conta Telegram. Abra/entre no canal ou use o @username público do destino.', 0, $first);
            }
        }
    }

    private function sendMediaWithSafeCaption(string $peer, mixed $media, string $text, array $entities=[]): void
    {
        // O Telegram aceita no máximo 1024 caracteres na legenda de uma mídia.
        [$caption, $rest, $captionEntities, $restEntities] = $this->splitCaption($text, $entities, 1024);
        $params = ['peer'=>$peer, 'media'=>$media, 'message'=>$caption, 'entities'=>$captionEntities];
        $this->messages->sendMedia(...$params);
        if ($rest !== '') $this->sendContinuation($peer, $rest, $restEntities);
    }

    /** @return array{0:string,1:string,2:array,3:array} */
    private function splitCaption(string $text, array $entities, int $limit): array
    {
        $chars=preg_split('//u',$text,-1,PREG_SPLIT_NO_EMPTY) ?: [];
        $units=0; $cut=count($chars);
        foreach($chars as $i=>$char){$size=(int)(strlen(mb_convert_encoding($char,'UTF-16LE','UTF-8'))/2);if($units+$size>$limit){$cut=$i;break;}$units+=$size;}
        if($cut===count($chars)) return [$text,'',$entities,[]];
        $caption=implode('',array_slice($chars,0,$cut)); $rest=implode('',array_slice($chars,$cut));
        $first=[];$second=[];
        foreach($entities as $entity){$offset=(int)($entity['offset']??0);$length=(int)($entity['length']??0);$end=$offset+$length;$copy=$entity;if($offset<$units&&$end>0){$copy['offset']=$offset;$copy['length']=min($end,$units)-$offset;if($copy['length']>0)$first[]=$copy;}if($end>$units){$copy=$entity;$copy['offset']=max(0,$offset-$units);$copy['length']=$end-max($offset,$units);if($copy['length']>0)$second[]=$copy;}}
        return [$caption,$rest,$first,$second];
    }

    private function sendContinuation(string $peer, string $text, array $entities): void
    {
        $label = "↪️ Continuação da mensagem:";
        $prefix = $label . "\n\n";
        $prefixUnits = (int)(strlen(mb_convert_encoding($prefix, 'UTF-16LE', 'UTF-8')) / 2);
        $labelUnits = (int)(strlen(mb_convert_encoding($label, 'UTF-16LE', 'UTF-8')) / 2);
        $shifted=[['_'=>'messageEntityBold','offset'=>0,'length'=>$labelUnits]];
        foreach ($entities as $entity) { $copy=$entity; $copy['offset']=(int)($copy['offset']??0)+$prefixUnits; $shifted[]=$copy; }
        $params = ['peer'=>$peer, 'message'=>$prefix.$text, 'entities'=>$shifted];
        $this->messages->sendMessage(...$params);
    }

    private function findAndClaimPreviousPhoto(Message $message, string $source, int $eventId): mixed
    {
        $eventDate = (int) ($message->date ?? time());
        $history = $this->messages->getHistory(peer: $message->chatId, offset_id: $eventId, limit: 25);
        foreach (($history['messages'] ?? []) as $candidate) {
            $candidateId = (int) ($candidate['id'] ?? 0);
            $candidateDate = (int) ($candidate['date'] ?? 0);
            $media = $candidate['media'] ?? null;
            $isPhoto = is_array($media) && (($media['_'] ?? '') === 'messageMediaPhoto' || isset($media['photo'])) || (is_object($candidate) && !empty($candidate->media));
            if (!$candidateId || !$candidateDate || !$isPhoto || $candidateDate > $eventDate || ($eventDate - $candidateDate) > 900) continue;
            $claim = Database::pdo()->prepare('INSERT INTO router_media_claims(source_chat,media_message_id,event_message_id,media_date,event_date) VALUES(?,?,?,?,?)');
            try {
                $claim->execute([$source, $candidateId, $eventId, date('Y-m-d H:i:s', $candidateDate), date('Y-m-d H:i:s', $eventDate)]);
                return $candidate;
            } catch (\PDOException $e) {
                if ((int) ($e->errorInfo[1] ?? 0) === 1062) continue;
                throw $e;
            }
        }
        return null;
    }

    private function finish(string $source, int $id, string $status, string $details): void
    {
        $s = Database::pdo()->prepare('UPDATE router_events SET status=?,details=?,updated_at=NOW() WHERE source_chat=? AND message_id=?');
        $s->execute([$status, $details, $source, $id]);
    }
}

final class WorkerStatus
{
    public static function error(string $message): void
    {
        try { Database::pdo()->prepare("INSERT INTO worker_status(worker_key,status,last_activity_at,last_error) VALUES('telegram-global','erro',NOW(),?) ON DUPLICATE KEY UPDATE status='erro',last_activity_at=NOW(),last_error=?")->execute([$message, $message]); } catch (\Throwable) {}
    }
}

register_shutdown_function(static function (): void {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR], true)) WorkerStatus::error($error['message']);
});
